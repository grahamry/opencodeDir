<template>
  <div class="quality-management">
    <router-view />
  </div>
</template>

<script setup>
// 质量管理主组件
</script>

<style scoped>
.quality-management {
  height: 100%;
}
</style> 