<template>
  <div class="finance-content">
    <router-view></router-view>
  </div>
</template>

<script setup>
// 财务模块入口
</script>

<style scoped>
.finance-content {
  padding: 20px;
}
</style> 